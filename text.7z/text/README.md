# HTML-CSS-Responsive-Website

## Öncelikle Merhaba Arkadaşlar 
### Dosyaları bilgisayarınıza indirdikten sonra [Visual Studio Code](https://code.visualstudio.com) ile dosyaları açın.
Daha sonra [Live Server](https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer) indirin ve vidyoda gösterdiğim şekilde çalıştırın.

#### Haydi inşa edelim ! 
